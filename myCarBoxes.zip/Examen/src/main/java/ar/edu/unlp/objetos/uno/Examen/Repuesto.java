package ar.edu.unlp.objetos.uno.Examen;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Repuesto {
	private String nombre;
	private LocalDate fabricacion;
	private double costo;
	
	public Repuesto() {
		
	}
	public Repuesto(String nom, LocalDate fab, double cost) {
		this.nombre = nom;
		this.fabricacion = fab;
		this.costo = cost;
	}
	
	public double getCosto() {
		return this.costo;
	}
	public boolean antiguedadMayor5() {
		if(ChronoUnit.YEARS.between(this.fabricacion, LocalDate.now()) > 5)
			return true;
		else
			return false;
	}
}
