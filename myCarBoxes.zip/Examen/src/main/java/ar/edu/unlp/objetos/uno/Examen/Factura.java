package ar.edu.unlp.objetos.uno.Examen;

import java.time.LocalDate;

public class Factura {
	private String patente;
	private LocalDate fecha;
	private double montoFinal;
	private double descuento;
	
	public Factura(String pat, LocalDate fec, double montF, double desc) {
		this.patente = pat;
		this.fecha = fec;
		this.montoFinal = montF;
		this.descuento = desc;
	}
	
	
}
