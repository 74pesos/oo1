package ar.edu.unlp.objetos.uno.Examen;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;

public abstract class Orden {
	private String patente;
	protected ArrayList<Repuesto> repuestos;
	private LocalDate fecha;
	
	public Orden() {
		
	}
	public Orden(String pat, ArrayList<Repuesto> reps) {
		this.patente = pat;
		repuestos = reps;
		this.fecha = LocalDate.now();
	}
	
	public boolean ultimos12() {
		if(ChronoUnit.MONTHS.between(fecha, LocalDate.now()) > 12)
			return true;
		else
			return false;
	}
	
	public double gastosRepuestos() {
		if(repuestos.isEmpty())
			return 0;
		else
			return repuestos.stream().mapToDouble(a-> a.getCosto())
					.sum();
	}
	public String getPatente() {
		return this.getPatente();
	}
	public boolean listaConRepuestoAntiguo() {
		return this.repuestos.stream().anyMatch(a-> a.antiguedadMayor5());
	}
	public abstract double calcularOrden();
	
	public double calcularDescuentoDesdeEntero(int descuento) {
		return descuento*(calcularOrden()/100);
	}
	public double aplicarDescuentoTotal(int descuento) {
		return calcularOrden()-calcularDescuentoDesdeEntero(descuento);
	}
	
}
