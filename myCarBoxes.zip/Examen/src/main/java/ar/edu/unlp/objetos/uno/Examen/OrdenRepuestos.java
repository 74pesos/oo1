package ar.edu.unlp.objetos.uno.Examen;

import java.util.ArrayList;

public class OrdenRepuestos extends Orden{
	public OrdenRepuestos() {
		
	}
	
	public OrdenRepuestos(String pat, ArrayList<Repuesto> reps) {
		super(pat,reps);
	}
	
	public double calcularOrden() {
		double ret = this.gastosRepuestos();
		if(this.listaConRepuestoAntiguo())
			return ret *1.08;
		else 
			return ret * 1.15;
	}
}
