package ar.edu.unlp.objetos.uno.Examen;

public class Empleado {
	private String nombre;
	private double valorXHora;
	
	public Empleado() {
		
	}
	public Empleado(String nom, double vaX) {
		this.nombre = nom;
		this.valorXHora = vaX;
	}
	
	public double cobrar(int horas) {
		return valorXHora * horas;
	}
}
