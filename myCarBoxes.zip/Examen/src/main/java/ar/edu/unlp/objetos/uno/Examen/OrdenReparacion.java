package ar.edu.unlp.objetos.uno.Examen;

import java.util.ArrayList;

public class OrdenReparacion extends Orden{
	private String descripcion;
	private ArrayList<Empleado> empleados;
	private int horas;
	
	public OrdenReparacion() {
		
	}
	public OrdenReparacion(String pat, String desc, ArrayList<Empleado> emples,ArrayList<Repuesto> reps, int hor) {
		super(pat, reps);
		this.descripcion = desc;
		this.horas = hor;
		this.empleados = emples;
	}
	
	public double calcularOrden() {
		double ret = empleados.stream()
					 .mapToDouble(a-> a.cobrar(this.horas))
					 .sum();
		ret += this.gastosRepuestos();
		return ret *1.10;
		
	}
}
