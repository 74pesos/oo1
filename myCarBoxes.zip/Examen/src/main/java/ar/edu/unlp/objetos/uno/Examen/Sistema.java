package ar.edu.unlp.objetos.uno.Examen;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Sistema {
	private ArrayList<Repuesto> repuestos;
	private ArrayList<Empleado> empleados;
	private ArrayList<Orden> ordenes;
	
	public Sistema() {
		repuestos = new ArrayList<Repuesto>();
		empleados = new ArrayList<Empleado>();
		ordenes = new ArrayList<Orden>();
	}
	
	public Repuesto altaRepuesto(String nombre, LocalDate fab, double costo) {
		Repuesto aux = new Repuesto(nombre, fab, costo);
		repuestos.add(aux);
		return aux;
	}
	
	public Empleado altaempleado(String nombre, double vaX) {
		Empleado aux = new Empleado(nombre, vaX);
		empleados.add(aux);
		return aux;
	}
	public OrdenRepuestos altaORepuestos(String patente, ArrayList<Repuesto> reps) {
		OrdenRepuestos aux = new OrdenRepuestos(patente, reps);
		ordenes.add(aux);
		return aux;
	}
	public OrdenReparacion altaOReparacion(String patente, String desc, ArrayList<Repuesto> reps, ArrayList<Empleado> emples, int horas) {
		OrdenReparacion aux = new OrdenReparacion(patente, desc,emples, reps, horas);
		ordenes.add(aux);
		return aux;
	}
	
	public List<Factura> facturarConLista(List<Orden> listaOrdenes){
		List<Factura> facturas = new ArrayList<Factura>();
		List<String> patentes12 = ordenes.stream().filter(o-> o.ultimos12()).map(o->o.getPatente()).collect(Collectors.toList());
		listaOrdenes.forEach(o->{
			int descuento;
			if(patentes12.contains(o.getPatente()))
				descuento = 5;
			else 
				descuento =0;
			Factura aux = new Factura(o.getPatente(),LocalDate.now(),o.aplicarDescuentoTotal(descuento),descuento);
			facturas.add(aux);
		});
		return facturas;
	}
	
}
